﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'jp', {
    WordCount: '単語数:',
    CharCount: '文字数:',
    CharCountWithHTML: ' (with HTML: %charCountHTML%)',
    Paragraphs: 'Paragraphs:',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'ワードカウント'
});